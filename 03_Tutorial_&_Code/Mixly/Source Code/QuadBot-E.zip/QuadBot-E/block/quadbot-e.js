//下列三行代码,为刚需,此提供了下列所有代码的入口
'use strict';
 
goog.provide('Blockly.Blocks.quadbot-e');//注意脚本类别及路径名称
 
goog.require('Blockly.Blocks');

//板载LED引脚初始化
Blockly.Blocks.initLed = {
  	init: function() {
    	this.setColour(20);
    	this.appendDummyInput("")
    		.appendField("设置板载LED引脚为输出")
 
    	this.setPreviousStatement(true, null);
    	this.setNextStatement(true, null);
  	}
};

//板载LED亮
Blockly.Blocks.ledOn = {
  	init: function() {
    	this.setColour(20);
    	this.appendDummyInput("")
    		.appendField("板载LED亮")
 
    	this.setPreviousStatement(true, null);
    	this.setNextStatement(true, null);
  	}
};

//板载LED灭
Blockly.Blocks.ledOff = {
  	init: function() {
    	this.setColour(20);
    	this.appendDummyInput("")
    		.appendField("板载LED灭")
 
    	this.setPreviousStatement(true, null);
    	this.setNextStatement(true, null);
  	}
};

//板载LED闪烁
Blockly.Blocks.blink = {
  	init: function() {
    	this.setColour(20);
    	this.appendDummyInput("")
			.appendField("LED以");
		this.appendValueInput("delayTime")
			.setCheck(Number);
		this.appendDummyInput().appendField("毫秒延时闪烁");
    	this.setPreviousStatement(true, null);
    	this.setNextStatement(true, null);
  	}
};

//舵机旋转指定角度
Blockly.Blocks.servoRotateTo = {
	init: function() {
		this.setColour(20);
		this.appendDummyInput("")
			.appendField(new Blockly.FieldDropdown([["端口1","D4"],["端口2","D2"],["端口3","D3"],["端口4","D1"],["端口5","D0"],["端口6","D5"],["端口7","D6"],["端口8","A0"],["端口9","D7"],["端口10","D8"]]), "port")
			.appendField("舵机旋转到");
		this.appendValueInput("angle")
			.setCheck(Number);
		this.appendDummyInput().appendField("度");
		this.setPreviousStatement(true, null);
		this.setNextStatement(true, null);
	}
};

//舵机从0度循环旋转指定角度
Blockly.Blocks.servoSweep = {
	init: function() {
		this.setColour(20);
		this.appendDummyInput("")
			.appendField("舵机 端口")
			.appendField(new Blockly.FieldDropdown([["端口1","D4"],["端口2","D2"],["端口3","D3"],["端口4","D1"],["端口5","D0"],["端口6","D5"],["端口7","D6"],["端口8","A0"],["端口9","D7"],["端口10","D8"]]), "port")
			.appendField("从0度以");
		this.appendValueInput("delayTime")
			.setCheck(Number);
		this.appendDummyInput().appendField("毫秒的延迟时间循环旋转到(0-180)");
		this.appendValueInput("angle")
			.setCheck(Number);
		this.appendDummyInput().appendField("度");
		this.setPreviousStatement(true, null);
		this.setNextStatement(true, null);
	}
};

//安装模块
Blockly.Blocks.setup = {
	init:function(){
		this.setColour(20);
		this.appendDummyInput("")
			.appendField("安装");
		this.setPreviousStatement(true, null);
		this.setNextStatement(true, null);
	}
};

//校准模块
Blockly.Blocks.calibration = {
	init:function(){
		this.setColour(20);
		this.appendDummyInput("")
			.appendField("校准");
		this.setPreviousStatement(true, null);
		this.setNextStatement(true, null);
	}
};

//待机模块
Blockly.Blocks.standby = {
	init:function(){
		this.setColour(20);
		this.appendDummyInput("")
			.appendField("待机");
		this.setPreviousStatement(true, null);
		this.setNextStatement(true, null);
	}
};

//前进模块
Blockly.Blocks.forward = {
	init:function(){
		this.setColour(20);
		this.appendDummyInput("")
			.appendField("前进");
		this.setPreviousStatement(true, null);
		this.setNextStatement(true, null);
	}
};

//后退模块
Blockly.Blocks.backward = {
	init:function(){
		this.setColour(20);
		this.appendDummyInput("")
			.appendField("后退");
		this.setPreviousStatement(true, null);
		this.setNextStatement(true, null);
	}
};

//左移模块
Blockly.Blocks.leftshift = {
	init:function(){
		this.setColour(20);
		this.appendDummyInput("")
			.appendField("左移");
		this.setPreviousStatement(true, null);
		this.setNextStatement(true, null);
	}
};

//右移模块
Blockly.Blocks.rightshift = {
	init:function(){
		this.setColour(20);
		this.appendDummyInput("")
			.appendField("右移");
		this.setPreviousStatement(true, null);
		this.setNextStatement(true, null);
	}
};

//左转模块
Blockly.Blocks.turnleft = {
	init:function(){
		this.setColour(20);
		this.appendDummyInput("")
			.appendField("左转");
		this.setPreviousStatement(true, null);
		this.setNextStatement(true, null);
	}
};

//右转模块
Blockly.Blocks.turnright = {
	init:function(){
		this.setColour(20);
		this.appendDummyInput("")
			.appendField("右转");
		this.setPreviousStatement(true, null);
		this.setNextStatement(true, null);
	}
};

//躺下模块
Blockly.Blocks.lie = {
	init:function(){
		this.setColour(20);
		this.appendDummyInput("")
			.appendField("躺下");
		this.setPreviousStatement(true, null);
		this.setNextStatement(true, null);
	}
};

//打招呼模块
Blockly.Blocks.hello = {
	init:function(){
		this.setColour(20);
		this.appendDummyInput("")
			.appendField("打招呼");
		this.setPreviousStatement(true, null);
		this.setNextStatement(true, null);
	}
};

//战斗模块
Blockly.Blocks.fighting = {
	init:function(){
		this.setColour(20);
		this.appendDummyInput("")
			.appendField("战斗");
		this.setPreviousStatement(true, null);
		this.setNextStatement(true, null);
	}
};

//俯卧撑模块
Blockly.Blocks.pushup = {
	init:function(){
		this.setColour(20);
		this.appendDummyInput("")
			.appendField("俯卧撑");
		this.setPreviousStatement(true, null);
		this.setNextStatement(true, null);
	}
};

//睡眠模块
Blockly.Blocks.sleep = {
	init:function(){
		this.setColour(20);
		this.appendDummyInput("")
			.appendField("睡眠");
		this.setPreviousStatement(true, null);
		this.setNextStatement(true, null);
	}
};

//舞步1模块
Blockly.Blocks.dance1 = {
	init:function(){
		this.setColour(20);
		this.appendDummyInput("")
			.appendField("舞步1");
		this.setPreviousStatement(true, null);
		this.setNextStatement(true, null);
	}
};

//舞步2模块
Blockly.Blocks.dance2 = {
	init:function(){
		this.setColour(20);
		this.appendDummyInput("")
			.appendField("舞步2");
		this.setPreviousStatement(true, null);
		this.setNextStatement(true, null);
	}
};

//舞步3模块
Blockly.Blocks.dance3 = {
	init:function(){
		this.setColour(20);
		this.appendDummyInput("")
			.appendField("舞步3");
		this.setPreviousStatement(true, null);
		this.setNextStatement(true, null);
	}
};

//回中模块
Blockly.Blocks.center = {
	init:function(){
		this.setColour(20);
		this.appendDummyInput("")
			.appendField("回中");
		this.setPreviousStatement(true, null);
		this.setNextStatement(true, null);
	}
};

//复位模块
Blockly.Blocks.zero = {
	init:function(){
		this.setColour(20);
		this.appendDummyInput("")
			.appendField("复位");
		this.setPreviousStatement(true, null);
		this.setNextStatement(true, null);
	}
};

//遥控模块
Blockly.Blocks.wifiControl = {
	init:function(){
		this.setColour(20);
		this.appendDummyInput("")
			.appendField("wifi遥控模式");
		this.setPreviousStatement(true, null);
		this.setNextStatement(true, null);
	}
};
