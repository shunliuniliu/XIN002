
//下列三行代码,为刚需,此提供了下列所有代码的入口
'use strict';
 
goog.provide('Blockly.Arduino.quadbot-e');//注意脚本类别及路径名称
 
goog.require('Blockly.Arduino');
  
//板载LED引脚初始化
Blockly.Arduino.initLed = function() {
    Blockly.Arduino.setups_['setup_intLed'] = 'pinMode(LED_BUILTIN, OUTPUT);\n';//严格函数固定写法(转setup函数中代码)
    return '';
};

//板载LED亮
Blockly.Arduino.ledOn = function() {
    var code = 'digitalWrite(LED_BUILTIN, HIGH);\n';//严格函数固定写法(转setup函数中代码)
    return code;
};

//板载LED灭
Blockly.Arduino.ledOff = function() {
    var code = 'digitalWrite(LED_BUILTIN, LOW);\n';//严格函数固定写法(转setup函数中代码)
    return code;
};

//板载LED闪烁
Blockly.Arduino.blink = function() {
	Blockly.Arduino.setups_['setup_intLed'] = 'pinMode(LED_BUILTIN, OUTPUT);\n';
	var delaytime = Blockly.Arduino.valueToCode(this, 'delayTime', Blockly.Arduino.ORDER_ATOMIC) || '0';
    var code = 'digitalWrite(LED_BUILTIN, HIGH);\ndelay('+delaytime+');\ndigitalWrite(LED_BUILTIN, LOW);\ndelay('+delaytime+');\n';//严格函数固定写法(转setup函数中代码)
    return code;
};

//舵机旋转指定角度
Blockly.Arduino.servoRotateTo = function() {
	Blockly.Arduino.definitions_['define_servo'] = '#include <Servo.h>';
	var port = this.getFieldValue('port');
	Blockly.Arduino.definitions_['Servo_'+port] = 'Servo servo_'+port+';';
	var DEGREE=Blockly.Arduino.valueToCode(this, 'angle', Blockly.Arduino.ORDER_ATOMIC) || '0';
	var code='servo_'+port+'.attach('+port+');\nservo_'+port+'.write('+DEGREE+');\n';
	return code;
};

//舵机从0度循环旋转指定角度
Blockly.Arduino.servoSweep = function() {
	Blockly.Arduino.definitions_['define_servo'] = '#include <Servo.h>';
	var port = this.getFieldValue('port');
	Blockly.Arduino.definitions_['Servo_'+port] = 'Servo servo_'+port+';';
	var DEGREE=Blockly.Arduino.valueToCode(this, 'angle', Blockly.Arduino.ORDER_ATOMIC) || '0';
	var delay=Blockly.Arduino.valueToCode(this, 'delayTime', Blockly.Arduino.ORDER_ATOMIC) || '0';
	
	Blockly.Arduino.setups_['servo_attach'] = 'servo_'+port+'.attach('+port+');';
	var code='  for(int pos=0; pos<='+DEGREE+'; pos++)\n  {\n    servo_'+port+'.write(pos);\n    delay('+delay+');\n  }\n' +
			 '  for(int pos='+DEGREE+'; pos>=0; pos--)\n  {\n    servo_'+port+'.write(pos);\n    delay('+delay+');\n  }';
	return code;
};

//安装模块
Blockly.Arduino.setup = function() {
	Blockly.Arduino.definitions_['define_servo'] = '#include <Servo.h>';
	Blockly.Arduino.definitions_['define_eeprom'] = '#include <EEPROM.h>';
	Blockly.Arduino.definitions_['define_xinbot'] = '#include <xinbot.h>';
	Blockly.Arduino.definitions_['define_webserver'] = '#include <webserver.h>\n';
	
	Blockly.Arduino.definitions_['define_bot'] = 'XinBot robot;';
	
	Blockly.Arduino.setups_['setup'] = 'Serial.begin(9600);\n  Serial.println("QuadBot-E Start!");\n  delay(1000);\n' +
									   '  webinit();\n  robot.init();\n  robot.Servo_Setup();';

	// var code='robot.setup();';
	// return code;
};

//校准模块
Blockly.Arduino.calibration = function() {
	Blockly.Arduino.definitions_['define_servo'] = '#include <Servo.h>';
	Blockly.Arduino.definitions_['define_eeprom'] = '#include <EEPROM.h>';
	Blockly.Arduino.definitions_['define_xinbot'] = '#include <xinbot.h>';
	Blockly.Arduino.definitions_['define_webserver'] = '#include <webserver.h>\n';
	
	Blockly.Arduino.definitions_['define_bot'] = 'XinBot robot;';
	
	Blockly.Arduino.setups_['setup'] = 'Serial.begin(9600);\n  Serial.println("QuadBot-E Start!");\n  delay(1000);\n' +
									   '  webinit();\n  robot.init();\n  robot.Servo_Setup();';

	var code='if(GPIO_ID < 100)\n{\n  robot.Set_PWM_to_Servo(GPIO_ID, ival.toInt());\n  GPIO_ID = 100;\n  ival = "";\n}';
	return code;
};

//待机模块
Blockly.Arduino.standby = function() {
	Blockly.Arduino.definitions_['define_servo'] = '#include <Servo.h>';
	Blockly.Arduino.definitions_['define_eeprom'] = '#include <EEPROM.h>';
	Blockly.Arduino.definitions_['define_xinbot'] = '#include <xinbot.h>';
	Blockly.Arduino.definitions_['define_webserver'] = '#include <webserver.h>\n';
	
	Blockly.Arduino.definitions_['define_bot'] = 'XinBot robot;';
	
	Blockly.Arduino.setups_['setup'] = 'Serial.begin(9600);\n  Serial.println("QuadBot-E Start!");\n  delay(1000);\n' +
									   '  webinit();\n  robot.init();\n  robot.Servo_Setup();';

	var code='robot.standby();';
	return code;
};

//前进模块
Blockly.Arduino.forward = function() {
	Blockly.Arduino.definitions_['define_servo'] = '#include <Servo.h>';
	Blockly.Arduino.definitions_['define_eeprom'] = '#include <EEPROM.h>';
	Blockly.Arduino.definitions_['define_xinbot'] = '#include <xinbot.h>';
	Blockly.Arduino.definitions_['define_webserver'] = '#include <webserver.h>\n';
	
	Blockly.Arduino.definitions_['define_bot'] = 'XinBot robot;';
	
	Blockly.Arduino.setups_['setup'] = 'Serial.begin(9600);\n  Serial.println("QuadBot-E Start!");\n  delay(1000);\n' +
									   '  webinit();\n  robot.init();\n  robot.Servo_Setup();';

	var code='robot.forward();';
	return code;
};

//后退模块
Blockly.Arduino.backward = function() {
	Blockly.Arduino.definitions_['define_servo'] = '#include <Servo.h>';
	Blockly.Arduino.definitions_['define_eeprom'] = '#include <EEPROM.h>';
	Blockly.Arduino.definitions_['define_xinbot'] = '#include <xinbot.h>';
	Blockly.Arduino.definitions_['define_webserver'] = '#include <webserver.h>\n';
	
	Blockly.Arduino.definitions_['define_bot'] = 'XinBot robot;';
	
	Blockly.Arduino.setups_['setup'] = 'Serial.begin(9600);\n  Serial.println("QuadBot-E Start!");\n  delay(1000);\n' +
									   '  webinit();\n  robot.init();\n  robot.Servo_Setup();';

	var code='robot.backward();';
	return code;
};

//左移模块
Blockly.Arduino.leftshift = function() {
	Blockly.Arduino.definitions_['define_servo'] = '#include <Servo.h>';
	Blockly.Arduino.definitions_['define_eeprom'] = '#include <EEPROM.h>';
	Blockly.Arduino.definitions_['define_xinbot'] = '#include <xinbot.h>';
	Blockly.Arduino.definitions_['define_webserver'] = '#include <webserver.h>\n';
	
	Blockly.Arduino.definitions_['define_bot'] = 'XinBot robot;';
	
	Blockly.Arduino.setups_['setup'] = 'Serial.begin(9600);\n  Serial.println("QuadBot-E Start!");\n  delay(1000);\n' +
									   '  webinit();\n  robot.init();\n  robot.Servo_Setup();';

	var code='robot.leftshift();';
	return code;
};

//右移模块
Blockly.Arduino.rightshift = function() {
	Blockly.Arduino.definitions_['define_servo'] = '#include <Servo.h>';
	Blockly.Arduino.definitions_['define_eeprom'] = '#include <EEPROM.h>';
	Blockly.Arduino.definitions_['define_xinbot'] = '#include <xinbot.h>';
	Blockly.Arduino.definitions_['define_webserver'] = '#include <webserver.h>\n';
	
	Blockly.Arduino.definitions_['define_bot'] = 'XinBot robot;';
	
	Blockly.Arduino.setups_['setup'] = 'Serial.begin(9600);\n  Serial.println("QuadBot-E Start!");\n  delay(1000);\n' +
									   '  webinit();\n  robot.init();\n  robot.Servo_Setup();';

	var code='robot.rightshift();';
	return code;
};

//左转模块
Blockly.Arduino.turnleft = function() {
	Blockly.Arduino.definitions_['define_servo'] = '#include <Servo.h>';
	Blockly.Arduino.definitions_['define_eeprom'] = '#include <EEPROM.h>';
	Blockly.Arduino.definitions_['define_xinbot'] = '#include <xinbot.h>';
	Blockly.Arduino.definitions_['define_webserver'] = '#include <webserver.h>\n';
	
	Blockly.Arduino.definitions_['define_bot'] = 'XinBot robot;';
	
	Blockly.Arduino.setups_['setup'] = 'Serial.begin(9600);\n  Serial.println("QuadBot-E Start!");\n  delay(1000);\n' +
									   '  webinit();\n  robot.init();\n  robot.Servo_Setup();';

	var code='robot.turnleft();';
	return code;
};

//右转模块
Blockly.Arduino.turnright = function() {
	Blockly.Arduino.definitions_['define_servo'] = '#include <Servo.h>';
	Blockly.Arduino.definitions_['define_eeprom'] = '#include <EEPROM.h>';
	Blockly.Arduino.definitions_['define_xinbot'] = '#include <xinbot.h>';
	Blockly.Arduino.definitions_['define_webserver'] = '#include <webserver.h>\n';
	
	Blockly.Arduino.definitions_['define_bot'] = 'XinBot robot;';
	
	Blockly.Arduino.setups_['setup'] = 'Serial.begin(9600);\n  Serial.println("QuadBot-E Start!");\n  delay(1000);\n' +
									   '  webinit();\n  robot.init();\n  robot.Servo_Setup();';

	var code='robot.turnright();';
	return code;
};

//躺下模块
Blockly.Arduino.lie = function() {
	Blockly.Arduino.definitions_['define_servo'] = '#include <Servo.h>';
	Blockly.Arduino.definitions_['define_eeprom'] = '#include <EEPROM.h>';
	Blockly.Arduino.definitions_['define_xinbot'] = '#include <xinbot.h>';
	Blockly.Arduino.definitions_['define_webserver'] = '#include <webserver.h>\n';
	
	Blockly.Arduino.definitions_['define_bot'] = 'XinBot robot;';
	
	Blockly.Arduino.setups_['setup'] = 'Serial.begin(9600);\n  Serial.println("QuadBot-E Start!");\n  delay(1000);\n' +
									   '  webinit();\n  robot.init();\n  robot.Servo_Setup();';

	var code='robot.lie();';
	return code;
};

//打招呼模块
Blockly.Arduino.hello = function() {
	Blockly.Arduino.definitions_['define_servo'] = '#include <Servo.h>';
	Blockly.Arduino.definitions_['define_eeprom'] = '#include <EEPROM.h>';
	Blockly.Arduino.definitions_['define_xinbot'] = '#include <xinbot.h>';
	Blockly.Arduino.definitions_['define_webserver'] = '#include <webserver.h>\n';
	
	Blockly.Arduino.definitions_['define_bot'] = 'XinBot robot;';
	
	Blockly.Arduino.setups_['setup'] = 'Serial.begin(9600);\n  Serial.println("QuadBot-E Start!");\n  delay(1000);\n' +
									   '  webinit();\n  robot.init();\n  robot.Servo_Setup();';

	var code='robot.hello();';
	return code;
};

//战斗模块
Blockly.Arduino.fighting = function() {
	Blockly.Arduino.definitions_['define_servo'] = '#include <Servo.h>';
	Blockly.Arduino.definitions_['define_eeprom'] = '#include <EEPROM.h>';
	Blockly.Arduino.definitions_['define_xinbot'] = '#include <xinbot.h>';
	Blockly.Arduino.definitions_['define_webserver'] = '#include <webserver.h>\n';
	
	Blockly.Arduino.definitions_['define_bot'] = 'XinBot robot;';
	
	Blockly.Arduino.setups_['setup'] = 'Serial.begin(9600);\n  Serial.println("QuadBot-E Start!");\n  delay(1000);\n' +
									   '  webinit();\n  robot.init();\n  robot.Servo_Setup();';

	var code='robot.fighting();';
	return code;
};

//俯卧撑模块
Blockly.Arduino.pushup = function() {
	Blockly.Arduino.definitions_['define_servo'] = '#include <Servo.h>';
	Blockly.Arduino.definitions_['define_eeprom'] = '#include <EEPROM.h>';
	Blockly.Arduino.definitions_['define_xinbot'] = '#include <xinbot.h>';
	Blockly.Arduino.definitions_['define_webserver'] = '#include <webserver.h>\n';
	
	Blockly.Arduino.definitions_['define_bot'] = 'XinBot robot;';
	
	Blockly.Arduino.setups_['setup'] = 'Serial.begin(9600);\n  Serial.println("QuadBot-E Start!");\n  delay(1000);\n' +
									   '  webinit();\n  robot.init();\n  robot.Servo_Setup();';

	var code='robot.pushup();';
	return code;
};

//睡眠模块
Blockly.Arduino.sleep = function() {
	Blockly.Arduino.definitions_['define_servo'] = '#include <Servo.h>';
	Blockly.Arduino.definitions_['define_eeprom'] = '#include <EEPROM.h>';
	Blockly.Arduino.definitions_['define_xinbot'] = '#include <xinbot.h>';
	Blockly.Arduino.definitions_['define_webserver'] = '#include <webserver.h>\n';
	
	Blockly.Arduino.definitions_['define_bot'] = 'XinBot robot;';
	
	Blockly.Arduino.setups_['setup'] = 'Serial.begin(9600);\n  Serial.println("QuadBot-E Start!");\n  delay(1000);\n' +
									   '  webinit();\n  robot.init();\n  robot.Servo_Setup();';

	var code='robot.sleep();';
	return code;
};

//舞步1模块
Blockly.Arduino.dance1 = function() {
	Blockly.Arduino.definitions_['define_servo'] = '#include <Servo.h>';
	Blockly.Arduino.definitions_['define_eeprom'] = '#include <EEPROM.h>';
	Blockly.Arduino.definitions_['define_xinbot'] = '#include <xinbot.h>';
	Blockly.Arduino.definitions_['define_webserver'] = '#include <webserver.h>\n';
	
	Blockly.Arduino.definitions_['define_bot'] = 'XinBot robot;';
	
	Blockly.Arduino.setups_['setup'] = 'Serial.begin(9600);\n  Serial.println("QuadBot-E Start!");\n  delay(1000);\n' +
									   '  webinit();\n  robot.init();\n  robot.Servo_Setup();';

	var code='robot.dance1();';
	return code;
};

//舞步2模块
Blockly.Arduino.dance2 = function() {
	Blockly.Arduino.definitions_['define_servo'] = '#include <Servo.h>';
	Blockly.Arduino.definitions_['define_eeprom'] = '#include <EEPROM.h>';
	Blockly.Arduino.definitions_['define_xinbot'] = '#include <xinbot.h>';
	Blockly.Arduino.definitions_['define_webserver'] = '#include <webserver.h>\n';
	
	Blockly.Arduino.definitions_['define_bot'] = 'XinBot robot;';
	
	Blockly.Arduino.setups_['setup'] = 'Serial.begin(9600);\n  Serial.println("QuadBot-E Start!");\n  delay(1000);\n' +
									   '  webinit();\n  robot.init();\n  robot.Servo_Setup();';

	var code='robot.dance2();';
	return code;
};

//舞步3模块
Blockly.Arduino.dance3 = function() {
	Blockly.Arduino.definitions_['define_servo'] = '#include <Servo.h>';
	Blockly.Arduino.definitions_['define_eeprom'] = '#include <EEPROM.h>';
	Blockly.Arduino.definitions_['define_xinbot'] = '#include <xinbot.h>';
	Blockly.Arduino.definitions_['define_webserver'] = '#include <webserver.h>\n';
	
	Blockly.Arduino.definitions_['define_bot'] = 'XinBot robot;';
	
	Blockly.Arduino.setups_['setup'] = 'Serial.begin(9600);\n  Serial.println("QuadBot-E Start!");\n  delay(1000);\n' +
									   '  webinit();\n  robot.init();\n  robot.Servo_Setup();';

	var code='robot.dance3();';
	return code;
};

//回中模块
Blockly.Arduino.center = function() {
	Blockly.Arduino.definitions_['define_servo'] = '#include <Servo.h>';
	Blockly.Arduino.definitions_['define_eeprom'] = '#include <EEPROM.h>';
	Blockly.Arduino.definitions_['define_xinbot'] = '#include <xinbot.h>';
	Blockly.Arduino.definitions_['define_webserver'] = '#include <webserver.h>\n';
	
	Blockly.Arduino.definitions_['define_bot'] = 'XinBot robot;';
	
	Blockly.Arduino.setups_['setup'] = 'Serial.begin(9600);\n  Serial.println("QuadBot-E Start!");\n  delay(1000);\n' +
									   '  webinit();\n  robot.init();\n  robot.Servo_Setup();';

	var code='robot.center();';
	return code;
};

//复位模块
Blockly.Arduino.zero = function() {
	Blockly.Arduino.definitions_['define_servo'] = '#include <Servo.h>';
	Blockly.Arduino.definitions_['define_eeprom'] = '#include <EEPROM.h>';
	Blockly.Arduino.definitions_['define_xinbot'] = '#include <xinbot.h>';
	Blockly.Arduino.definitions_['define_webserver'] = '#include <webserver.h>\n';
	
	Blockly.Arduino.definitions_['define_bot'] = 'XinBot robot;';
	
	Blockly.Arduino.setups_['setup'] = 'Serial.begin(9600);\n  Serial.println("QuadBot-E Start!");\n  delay(1000);\n' +
									   '  webinit();\n  robot.init();\n  robot.Servo_Setup();';

	var code='robot.zero();';
	return code;
};

//遥控模块
Blockly.Arduino.wifiControl = function() {
	Blockly.Arduino.definitions_['define_servo'] = '#include <Servo.h>';
	Blockly.Arduino.definitions_['define_eeprom'] = '#include <EEPROM.h>';
	Blockly.Arduino.definitions_['define_xinbot'] = '#include <xinbot.h>';
	Blockly.Arduino.definitions_['define_webserver'] = '#include <webserver.h>\n';
	
	Blockly.Arduino.definitions_['define_bot'] = 'XinBot robot;';
	
	Blockly.Arduino.setups_['setup'] = 'Serial.begin(9600);\n  Serial.println("QuadBot-E Start!");\n  delay(1000);\n' +
									   '  webinit();\n  robot.init();\n  robot.Servo_Setup();\n  enableWebServer();';

	var code='handleClient();\n\n  if (Servo_PROGRAM >= 1 )\n  {\n  switch (Servo_PROGRAM)\n  {\n  case 1:\n  robot.standby();\n  break;\n\n'+
			 '\tcase 2:\n  robot.forward();\n  break;\n\n'+
			 '\tcase 3:\n  robot.backward();\n  break;\n\n'+
			 '\tcase 4:\n  robot.leftshift();\n  break;\n\n'+
			 '\tcase 5:\n  robot.rightshift();\n  break;\n\n'+
			 '\tcase 6:\n  robot.turnleft();\n  break;\n\n'+
			 '\tcase 7:\n  robot.turnright();\n  break;\n\n'+
			 '\tcase 8:\n  robot.lie();\n  break;\n\n'+
			 '\tcase 9:\n  robot.hello();\n  break;\n\n'+
			 '\tcase 10:\n  robot.fighting();\n  break;\n\n'+
			 '\tcase 11:\n  robot.pushup();\n  break;\n\n'+
			 '\tcase 12:\n  robot.sleep();\n  break;\n\n'+
			 '\tcase 13:\n  robot.dance1();\n  break;\n\n'+
			 '\tcase 14:\n  robot.dance2();\n  break;\n\n'+
			 '\tcase 15:\n  robot.dance3();\n  break;\n\n'+
			 '\tcase 99:\n  robot.center();\n  break;\n\n'+
			 '\tcase 100:\n  robot.zero();\n  break;\n'+
			'}\n}';
	return code;
};
  